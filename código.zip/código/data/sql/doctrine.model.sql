CREATE TABLE juris_usuario(
 id BIGSERIAL,
 login VARCHAR(4000)
NOT NULL UNIQUE,
 senha VARCHAR(4000)
NOT NULL,
 nome VARCHAR(4000),
 instituicao VARCHAR(4000),
 email VARCHAR(4000),
 credential_id BIGINT NOT NULL,
 created_at TIMESTAMP without time zone,
 updated_at TIMESTAMP without time zone,
 PRIMARY KEY(id));

CREATE TABLE juris_tipocriterio(
 criterio_id INT,
 tipo_id INT,
 PRIMARY KEY(criterio_id,
 tipo_id));

CREATE TABLE juris_tipo(
 id BIGSERIAL,
 artigo VARCHAR(50)
NOT NULL,
 nome VARCHAR(255)
NOT NULL,
 lei_localizacao VARCHAR(50),
 ano_localizacao BIGINT,
 lei_redacao VARCHAR(50),
 ano_redacao BIGINT,
 lei_criacao VARCHAR(50),
 ano_criacao BIGINT,
 titulo VARCHAR(255),
 capitulo VARCHAR(255),
 pena_minima BIGINT,
 pena_maxima BIGINT,
 texto_legal VARCHAR(4000),
 obs_aplicacao VARCHAR(4000),
 notas_metodologicas VARCHAR(4000),
 simulado BOOLEAN,
 aprovado BOOLEAN,
 aprovadopor BIGINT,
 criadopor BIGINT,
 alteradopor BIGINT,
 created_at TIMESTAMP without time zone,
 updated_at TIMESTAMP without time zone,
 PRIMARY KEY(id));

CREATE TABLE juris_criterio(
 id BIGSERIAL,
 nome VARCHAR(255)
UNIQUE,
 categoria VARCHAR(255),
 descricao VARCHAR(4000),
 obs_aplicacao VARCHAR(4000),
 notas_metodologicas VARCHAR(4000),
 aprovado BOOLEAN,
 aprovadopor BIGINT,
 criadopor BIGINT,
 alteradopor BIGINT,
 created_at TIMESTAMP without time zone,
 updated_at TIMESTAMP without time zone,
 PRIMARY KEY(id));

CREATE TABLE juris_credential(
 id BIGINT,
 nome VARCHAR(4000),
 descricao VARCHAR(4000),
 PRIMARY KEY(id));

CREATE TABLE juris_beneficio(
 id BIGSERIAL,
 nome VARCHAR(255)
NOT NULL,
 lei_localizacao VARCHAR(50),
 ano_localizacao BIGINT,
 lei_atual VARCHAR(50),
 ano_atual BIGINT,
 lei_criacao VARCHAR(50),
 ano_criacao BIGINT,
 texto_legal VARCHAR(4000),
 descricao_completa VARCHAR(4000),
 criterio_nao_generalizavel VARCHAR(4000),
 notas_metodologicas VARCHAR(4000),
 expressao VARCHAR(4000),
 regra VARCHAR(4000),
 simulado BOOLEAN,
 aprovado BOOLEAN,
 aprovadopor BIGINT,
 criadopor BIGINT,
 alteradopor BIGINT,
 created_at TIMESTAMP without time zone,
 updated_at TIMESTAMP without time zone,
 PRIMARY KEY(id));

ALTER TABLE juris_usuario ADD FOREIGN KEY(
 credential_id)
REFERENCES juris_credential(id)
ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_tipocriterio ADD FOREIGN KEY(
 tipo_id)
REFERENCES juris_tipo(id)
ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_tipocriterio ADD FOREIGN KEY(
 criterio_id)
REFERENCES juris_criterio(id)
ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_tipo ADD FOREIGN KEY(
 criadoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_tipo ADD FOREIGN KEY(
 aprovadoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_tipo ADD FOREIGN KEY(
 alteradoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_criterio ADD FOREIGN KEY(
 criadoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_criterio ADD FOREIGN KEY(
 aprovadoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_criterio ADD FOREIGN KEY(
 alteradoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_beneficio ADD FOREIGN KEY(
 criadoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_beneficio ADD FOREIGN KEY(
 aprovadoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;

ALTER TABLE juris_beneficio ADD FOREIGN KEY(
 alteradoPor)
REFERENCES juris_usuario(id)
NOT DEFERRABLE INITIALLY IMMEDIATE;
