<?php

/**
 * ##MODULE_NAME## actions.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: actions.class.php,v 1.1 2006/12/08 18:49:35 nathanael Exp $
 */
class ##MODULE_NAME##Actions extends auto##MODULE_NAME##Actions
{
}
