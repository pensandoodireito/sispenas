<ul class="sf_admin_td_actions">
<li><?php echo link_to(image_tag('/sf/sf_admin/images/edit_icon.png', array('alt' => __('edit'), 'title' => __('edit'))), 'credential/edit?id='.$credential->get('id')) ?></li>
</ul>