<?php

/**
 * beneficio actions.
 *
 * @package    sf_sandbox
 * @subpackage beneficio
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 1415 2006-06-11 08:33:51Z fabien $
 */
class CredentialActions extends autoCredentialActions
{
}