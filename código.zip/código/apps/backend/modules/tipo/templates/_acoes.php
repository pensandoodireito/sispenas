<?php
  if($sf_user->hasCredential('Alimentador') and $tipo->get('aprovado')):
?>

<ul class="sf_admin_td_actions">
  <li><?php echo link_to(image_tag('/sf/sf_admin/images/edit_icon.png', array('alt' => __('edit'), 'title' => __('edit'))), 'tipo/show?id='.$tipo->get('id')) ?></li>
<?php
  else:
?>

<ul class="sf_admin_td_actions">
  <li><?php echo link_to(image_tag('/sf/sf_admin/images/edit_icon.png', array('alt' => __('edit'), 'title' => __('edit'))), 'tipo/edit?id='.$tipo->get('id')) ?></li>
  <li><?php echo link_to(image_tag('/sf/sf_admin/images/delete_icon.png', array('alt' => __('delete'), 'title' => __('delete'))), 'tipo/delete?id='.$tipo->get('id'), array (
  'post' => true,
  'confirm' => __('Tem certeza?'),
)) ?></li>

<?php
  endif;
?>

</ul>