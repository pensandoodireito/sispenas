<?php
  echo $tipo->get('RAprovadoPor')->getNome();
?>