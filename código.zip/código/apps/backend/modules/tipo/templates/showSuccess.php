<?php use_helper('ObjectDoctrineAdmin', 'Object', 'Date', 'I18N') ?>

<div id="sf_admin_container">

<?php echo object_input_hidden_tag($tipo, 'getid') ?>

<fieldset id="sf_fieldset_formul__rio_tipo" class="">
<h2><?php echo __('Formulário Tipo') ?></h2>


<div class="form-row">
  <?php echo label_for('tipo[artigo]', __($labels['tipo{artigo}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{artigo}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{artigo}')): ?>
    <?php echo form_error('tipo{artigo}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'artigo',
  ),
), array (
  'size' => 50,
  'control_name' => 'tipo[artigo]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[nome]', __($labels['tipo{nome}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{nome}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{nome}')): ?>
    <?php echo form_error('tipo{nome}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'nome',
  ),
), array (
  'size' => 80,
  'control_name' => 'tipo[nome]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[lei_localizacao]', __($labels['tipo{lei_localizacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{lei_localizacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{lei_localizacao}')): ?>
    <?php echo form_error('tipo{lei_localizacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'lei_localizacao',
  ),
), array (
  'size' => 50,
  'control_name' => 'tipo[lei_localizacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[ano_localizacao]', __($labels['tipo{ano_localizacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{ano_localizacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{ano_localizacao}')): ?>
    <?php echo form_error('tipo{ano_localizacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'ano_localizacao',
  ),
), array (
  'size' => 50,
  'control_name' => 'tipo[ano_localizacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[lei_redacao]', __($labels['tipo{lei_redacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{lei_redacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{lei_redacao}')): ?>
    <?php echo form_error('tipo{lei_redacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'lei_redacao',
  ),
), array (
  'size' => 50,
  'control_name' => 'tipo[lei_redacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[ano_redacao]', __($labels['tipo{ano_redacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{ano_redacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{ano_redacao}')): ?>
    <?php echo form_error('tipo{ano_redacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'ano_redacao',
  ),
), array (
  'size' => 7,
  'control_name' => 'tipo[ano_redacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[lei_criacao]', __($labels['tipo{lei_criacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{lei_criacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{lei_criacao}')): ?>
    <?php echo form_error('tipo{lei_criacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'lei_criacao',
  ),
), array (
  'size' => 50,
  'control_name' => 'tipo[lei_criacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[ano_criacao]', __($labels['tipo{ano_criacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{ano_criacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{ano_criacao}')): ?>
    <?php echo form_error('tipo{ano_criacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'ano_criacao',
  ),
), array (
  'size' => 7,
  'control_name' => 'tipo[ano_criacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[titulo]', __($labels['tipo{titulo}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{titulo}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{titulo}')): ?>
    <?php echo form_error('tipo{titulo}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'titulo',
  ),
), array (
  'size' => 80,
  'control_name' => 'tipo[titulo]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[capitulo]', __($labels['tipo{capitulo}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{capitulo}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{capitulo}')): ?>
    <?php echo form_error('tipo{capitulo}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'capitulo',
  ),
), array (
  'size' => 80,
  'control_name' => 'tipo[capitulo]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[pena_minima]', __($labels['tipo{pena_minima}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{pena_minima}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{pena_minima}')): ?>
    <?php echo form_error('tipo{pena_minima}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'pena_minima',
  ),
), array (
  'size' => 7,
  'control_name' => 'tipo[pena_minima]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[pena_maxima]', __($labels['tipo{pena_maxima}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{pena_maxima}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{pena_maxima}')): ?>
    <?php echo form_error('tipo{pena_maxima}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'pena_maxima',
  ),
), array (
  'size' => 7,
  'control_name' => 'tipo[pena_maxima]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[texto_legal]', __($labels['tipo{texto_legal}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{texto_legal}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{texto_legal}')): ?>
    <?php echo form_error('tipo{texto_legal}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_textarea_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'texto_legal',
  ),
), array (
  'size' => '30x3',
  'control_name' => 'tipo[texto_legal]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[obs_aplicacao]', __($labels['tipo{obs_aplicacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{obs_aplicacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{obs_aplicacao}')): ?>
    <?php echo form_error('tipo{obs_aplicacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_textarea_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'obs_aplicacao',
  ),
), array (
  'size' => '30x3',
  'control_name' => 'tipo[obs_aplicacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[notas_metodologicas]', __($labels['tipo{notas_metodologicas}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{notas_metodologicas}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{notas_metodologicas}')): ?>
    <?php echo form_error('tipo{notas_metodologicas}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_textarea_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'notas_metodologicas',
  ),
), array (
  'size' => '30x3',
  'control_name' => 'tipo[notas_metodologicas]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

    <?php if ($sf_user->hasCredential(array (   0 => 'Administrador', ))): ?>
<div class="form-row">
  <?php echo label_for('tipo[aprovado]', __($labels['tipo{aprovado}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{aprovado}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{aprovado}')): ?>
    <?php echo form_error('tipo{aprovado}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_checkbox_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'aprovado',
  ),
), array (
  'control_name' => 'tipo[aprovado]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>
    <?php endif; ?>

<div class="form-row">
  <?php echo label_for('tipo[simulacao]', __($labels['tipo{simulacao}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{simulacao}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{simulacao}')): ?>
    <?php echo form_error('tipo{simulacao}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_checkbox_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'simulacao',
  ),
), array (
  'control_name' => 'tipo[simulacao]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[aprovado_por]', __($labels['tipo{aprovado_por}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{aprovado_por}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{aprovado_por}')): ?>
    <?php echo form_error('tipo{aprovado_por}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_textarea_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'aprovado_por',
  ),
), array (
  'size' => '30x3',
  'control_name' => 'tipo[aprovado_por]',
  'readonly' => true,
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[criado_por]', __($labels['tipo{criado_por}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{criado_por}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{criado_por}')): ?>
    <?php echo form_error('tipo{criado_por}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'criado_por',
  ),
), array (
  'control_name' => 'tipo[criado_por]',
  'readonly' => true,
  'size' => 30,
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[created_at]', __($labels['tipo{created_at}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{created_at}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{created_at}')): ?>
    <?php echo form_error('tipo{created_at}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'created_at',
  ),
), array (
  'rich' => true,
  'withtime' => true,
  'calendar_button_img' => '/sf/sf_admin/images/date.png',
  'control_name' => 'tipo[created_at]',
  'readonly' => true,
  'size' => 30,
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[alterado_por]', __($labels['tipo{alterado_por}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{alterado_por}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{alterado_por}')): ?>
    <?php echo form_error('tipo{alterado_por}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'alterado_por',
  ),
), array (
  'control_name' => 'tipo[alterado_por]',
  'readonly' => true,
  'size' => 30,
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

<div class="form-row">
  <?php echo label_for('tipo[updated_at]', __($labels['tipo{updated_at}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{updated_at}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{updated_at}')): ?>
    <?php echo form_error('tipo{updated_at}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_input_tag($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'updated_at',
  ),
), array (
  'rich' => true,
  'withtime' => true,
  'calendar_button_img' => '/sf/sf_admin/images/date.png',
  'control_name' => 'tipo[updated_at]',
  'readonly' => true,
  'size' => 30,
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

</fieldset>
<fieldset id="sf_fieldset_crit__rios" class="">
<h2><?php echo __('Critérios') ?></h2>


<div class="form-row">
  <?php echo label_for('tipo[TipoCriterios]', __($labels['tipo{TipoCriterios}']), '') ?>
  <div class="content<?php if ($sf_request->hasError('tipo{TipoCriterios}')): ?> form-error<?php endif; ?>">
  <?php if ($sf_request->hasError('tipo{TipoCriterios}')): ?>
    <?php echo form_error('tipo{TipoCriterios}', array('class' => 'form-error-msg')) ?>
  <?php endif; ?>

  <?php $value = object_doctrine_admin_double_list($tipo, array (
  0 => 'get',
  1 => 
  array (
    0 => 'TipoCriterios',
  ),
), array (
  'control_name' => 'tipo[TipoCriterios]',
)); echo $value ? $value : '&nbsp;' ?>
    </div>
</div>

</fieldset>
</div>