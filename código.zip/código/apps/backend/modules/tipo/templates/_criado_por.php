<?php
  echo $tipo->get('RCriadoPor')->getNome();
?>