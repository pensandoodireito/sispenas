<?php  
  echo $tipo->get('RAlteradoPor')->getNome();
?>