<?php
  echo format_date($tipo->get('updated_at'), "dd/MM/yyyy");
?>