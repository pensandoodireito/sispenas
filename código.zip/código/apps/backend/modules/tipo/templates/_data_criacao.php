<?php
  echo format_date($tipo->get('created_at'), "dd/MM/yyyy");
?>