<?php

/**
 * tipo actions.
 *
 * @package    sf_sandbox
 * @subpackage tipo
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 1415 2006-06-11 08:33:51Z fabien $
 */
class tipoActions extends autotipoActions
{

  public function executeShow(){
    $this->preExecute();
    $this->tipo = Doctrine::getTable('Tipo')->find(array($this->getRequestParameter('id')));
    $this->labels = $this->getLabels();
  }
  
  protected function updateTipoFromRequest()
  {
    $idUsuario = $this->getUser()->getAttribute('loginId');
    
    $tipo = $this->getRequestParameter('tipo');
  
    $this->tipo->set('AlteradoPor', $idUsuario);    

    if(!isset($tipo['aprovado'])){
      $this->tipo->set('AprovadoPor', NULL);
    }

    if(isset($tipo['aprovado'])){
      $this->tipo->set('AprovadoPor', $idUsuario);  
    }

    if(!$this->tipo->get('created_at')){
      $this->tipo->set('CriadoPor', $idUsuario);      
    }

    parent::updateTipoFromRequest();
  }  
  
}
