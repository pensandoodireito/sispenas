<?php

/**
 * criterio actions.
 *
 * @package    sf_sandbox
 * @subpackage criterio
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 1415 2006-06-11 08:33:51Z fabien $
 */
class criterioActions extends autocriterioActions
{
  protected function updateCriterioFromRequest()
  {
    $idUsuario = $this->getUser()->getAttribute('loginId');
    
    $criterio = $this->getRequestParameter('criterio');
  
    $this->criterio->set('AlteradoPor', $idUsuario);    

    if(!isset($criterio['aprovado'])){
      $this->criterio->set('AprovadoPor', NULL);
    }

    if(isset($criterio['aprovado'])){
      $this->criterio->set('AprovadoPor', $idUsuario);  
    }

    if(!$this->criterio->get('created_at')){
      $this->criterio->set('CriadoPor', $idUsuario);      
    }

    parent::updateCriterioFromRequest();
  }
}
