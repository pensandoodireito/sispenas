<?php
  echo $criterio->get('RCriadoPor')->getNome();
?>