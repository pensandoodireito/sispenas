<?php
  echo format_date($criterio->get('created_at'), "dd/MM/yyyy");
?>