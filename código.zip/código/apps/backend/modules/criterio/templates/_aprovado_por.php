<?php
  echo $criterio->get('RAprovadoPor')->getNome();
?>