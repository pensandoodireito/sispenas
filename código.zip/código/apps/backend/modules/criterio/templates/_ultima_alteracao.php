<?php
  echo format_date($criterio->get('updated_at'), "dd/MM/yyyy");
?>