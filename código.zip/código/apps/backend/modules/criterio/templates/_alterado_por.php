<?php  
  echo $criterio->get('RAlteradoPor')->getNome();
?>