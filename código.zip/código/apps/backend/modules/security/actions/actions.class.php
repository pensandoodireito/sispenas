<?php

/**
 * security actions.
 *
 * @package    sf_sandbox
 * @subpackage security
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 2692 2006-11-15 21:03:55Z fabien $
 */
class securityActions extends sfActions
{
  /**
   * Executes index action
   *
   */
  public function executeIndex()
  {    
  }
  
  public function executeLogin()
  {
    $q = new Doctrine_Query();
    
    $login = $this->getRequestParameter('login');
    
    $senha = $this->getRequestParameter('senha');    

    $usuario = $q->select('u.login, u.nome')->from('Usuario u')->innerJoin('u.Credential c')->where('u.login = ? AND u.senha = ?', array($login, $senha))->execute()->getFirst();  

    if ($usuario)
    {
      $this->getUser()->setAuthenticated(true);
      
      $credential = $usuario->get('Credential');
      
      $this->getUser()->addCredential($credential->getNome());
      
      $this->getUser()->setAttribute('loginId', $usuario->get('id'));
   
      return $this->redirect('main/index');
    }
    else
    {
      $this->getRequest()->setError('login', 'Usuário ou senha Incorreto. Tente novamente.');
      return $this->forward('security', 'index');
    }
}
  
  
  
}
