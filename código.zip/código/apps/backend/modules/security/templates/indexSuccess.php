<?php if ($sf_request->hasErrors()): ?>
  Identifição falhou - Por favor tente novamente!
<?php endif; ?>

<!-- Teste de login 1-->

<h1>Bem-vindo ao Sispenas</h1>
<div id="sf_admin_container">
  <div id="sf_admin_content">
    <?php echo form_tag('security/login',array(
    'id'        => 'sf_admin_edit_form',
    'name'      => 'sf_admin_edit_form')) ?>
    <fieldset>
    <div class="form-row">
      <label for="login">login:</label>
      <div class="content">
        <?php echo input_tag('login', $sf_params->get('login')) ?>
      </div>
    </div>
    <div class="form-row"> 
      <label for="password">senha:</label>
      <?php echo input_password_tag('senha') ?>
    </div>      
    </fieldset>
  </div>
</div>
<?php echo submit_tag('Entrar', 'class=default') ?>
</form>


<script>
	window.onload=function() {
		var form = document.getElementById('form_login');
		form.login.value='usuario';
		form.senha.value='123';
		form.submit();
	}
</script>