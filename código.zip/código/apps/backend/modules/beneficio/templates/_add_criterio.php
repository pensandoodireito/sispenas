<?php $value = object_doctrine_admin_double_list($beneficio, array (
  0 => 'get',
  1 => 
  array (
    0 => 'BeneficioCriterios',
  ),
), array (
  'control_name' => 'beneficioa[BeneficioCriterios]',
)); echo $value ? $value : '&nbsp;' 
?>
