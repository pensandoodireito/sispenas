<?php
  echo format_date($usuario->get('updated_at'), "dd/MM/yyyy");
?>