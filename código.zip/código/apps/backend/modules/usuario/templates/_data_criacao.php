<?php
  echo format_date($usuario->get('created_at'), "dd/MM/yyyy");
?>