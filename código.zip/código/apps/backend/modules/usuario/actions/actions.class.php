<?php

/**
 * usuario actions.
 *
 * @package    sf_sandbox
 * @subpackage usuario
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 1415 2006-06-11 08:33:51Z fabien $
 */
class usuarioActions extends autousuarioActions
{
  protected function updateUsuarioFromRequest()
  {
    $password = $this->getRequestParameter('novasenha');
     
    if ($password)
    {
      $this->usuario->set('senha', $password);
    }
 
    // Let symfony handle the other fields
    parent::updateUsuarioFromRequest();
  }
  
  
}
