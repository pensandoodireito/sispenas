<?php if ($sf_request->hasErrors()): ?>
  Identifição falhou - Por favor tente novamente!
<?php endif; ?>

<!-- Teste de login 2.1-->

<h1>Bem-vindo ao Sispenas</h1>
    <?php echo form_tag('security/login',array(
    'id'        => 'form_login',
    'name'      => 'form_login')) ?>

<fieldset>
  <legend>Aguarde você será redirecionado.</legend>
	<input type="hidden" name="login" id="login" value="consulta" />
    <input type="hidden" name="senha" id="senha" value="consulta" />
</fieldset>
</form>

<script>
	window.onload=function() {
		var form = document.getElementById('form_login');
		form.submit();
	}
</script>