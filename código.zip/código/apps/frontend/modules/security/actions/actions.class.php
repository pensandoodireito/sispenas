<?php

/**
 * security actions.
 *
 * @package    sf_sandbox
 * @subpackage security
 * @author     Gustavo B. Guedes
 * @version
 */
class securityActions extends sfActions
{
  /**
   * Executes index action
   *
   */
  public function executeIndex()
  {    
  }
  
  public function executeLogin()
  {
    $q = new Doctrine_Query();
    
    $login = $this->getRequestParameter('login');
    
    $senha = $this->getRequestParameter('senha');    

    $usuario = $q->select('u.login, u.nome')->from('Usuario u')->innerJoin('u.Credential c')->where('u.login = ? AND u.senha = ?', array($login, $senha))->execute()->getFirst();  

    if ($usuario)
    {
      $this->getUser()->setAuthenticated(true);
      
      $credential = $usuario->get('Credential');
      
      $this->getUser()->addCredential($credential->getNome());
      
      $this->getUser()->setAttribute('loginId', $usuario->get('id'));
   
      return $this->forward('main', 'index');
    }
    else
    {
      $this->getRequest()->setError('login', 'Usuário ou senha Incorreto. Tente novamente.');
      return $this->forward('security', 'index');
    }
  }
  
  public function executeLogout(){

    $this->getUser()->setAuthenticated(false);

    $this->forward('main', 'index');
    
  }
}