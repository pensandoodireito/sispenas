<div style="font-family:Arial">

<p><span style="font-weight:bold;">APRESENTAÇÃO</span></p>

	<p>O SISPENAS é um banco de dados que sistematiza e organiza informações sobre os crimes previstos na legislação penal brasileira, suas respectivas penas e os benefícios que eventualmente possam ser concedidos para cada um desses crimes.</p>
    
	<p>Além de tornar mais clara e acessível a relação entre o conjunto de tipos penais e benefícios já positivados no nosso ordenamento, o banco de dados auxilia a formulação de alterações legislativas por meio de simulações (por exemplo, é possível saber quais crimes serão considerados de menor potencial ofensivo se for aprovado um projeto de lei de altera de dois para três anos o limite da pena máxima previsto no art. 61 da Lei nº. 9.099/1995).</p>
    
<br />
<a href="http://portal.mj.gov.br/data/Pages/MJCCFB3C67ITEMID3C94F3D79C204705BC8E84F8712478D1PTBRIE.htm">Entenda melhor o SisPenas</a>
<br />
<br /><br />

<p><span style="font-weight:bold;">COMO PESQUISAR</span></p>

	<p>A pesquisa pode ser realizada de diferentes formas: por artigo, benefício, ano de criação de leis, penas máximas e mínimas ou palavras-chave. Para iniciar a pesquisa, basta clicar em um dos ícones acima. </p>
    
	<p>A pesquisa em “tipos penais” permite consultar os crimes que constam no Código Penal (Decreto-lei n. 2.848/1940 e suas alterações) e em 55 leis penais especiais em vigor. O ícone “benefícios” sistematiza os seguintes institutos jurídicos: composição civil dos danos; transação penal; suspensão condicional do processo; substituição da pena privativa de liberdade por pena restritiva de direitos e/ou por pena de multa; suspensão condicional da pena; limite de cumprimento de pena e livramento condicional. Por fim, a “pesquisa avançada” (ou “filtro”, depende da terminologia que utilizarmos) possibilita o cruzamento entre o conjunto de tipos e o conjunto de benefícios, disponibilizando dois tipos de consulta: (i) para um dado benefício, verifica a quais tipos ele se aplica; (ii) para um dado tipo, verifica quais benefícios podem ser aplicados.</p>
    <br />
	<p>Para esclarecimentos no caso de dúvidas ou para ter acesso a mais informações sobre a metodologia adotada para a construção do SISPENAS, envie um e-mail para sal@mj.gov.br</p>
    
</div>