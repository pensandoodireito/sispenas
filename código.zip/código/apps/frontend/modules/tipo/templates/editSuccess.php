<?php use_helper('ObjectDoctrineAdmin', 'Object', 'Date', 'Validation', 'I18N') ?>
<?php if ($sf_request->hasErrors() && $sf_request->getError('create/update')):   
      echo $sf_request->getError('create/update'); 
?>
<?php elseif($sf_request->hasErrors()): ?>
  <div id="errors">
    <p>Foi encontrado erro nos campos abaixo.</p>
    <p>Por favor, corrija-o para prosseguir.</p>
  </div>
<?php endif; ?>

<?php echo form_tag('tipo/update', array(
  'id'        => 'sf_admin_edit_form',
  'name'      => 'sf_admin_edit_form',
  'multipart' => true,
  'onsubmit'  => 'double_list_submit(); return true;'
)) ?>

<?php echo object_input_hidden_tag($tipo, 'getid') ?>


<fieldset>
  <legend>Formulário Tipo</legend>
  <ul>
    <?php echo "<li><label></label>" . form_error('artigo') . "</li>" ?>
    <li>
      <label for="artigo">Artigo:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'artigo',
                                    ),
                                  ), 
                                  array (
                                    'size' => 50,
                                    'control_name' => 'artigo',
                                    'id' => 'artigo'
                                  )) ?>
    </li>
    <?php echo "<li><label></label>" . form_error('tipo') . "</li>" ?>
    <li>
      <label for="tipo">Tipo:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'nome',
                                    ),
                                  ), 
                                  array (
                                    'size' => 80,
                                    'control_name' => 'tipo',
                                    'id' => 'tipo'
                                  )) ?>
    </li>
    <li>
      <label for="lei_localizacao">Lei de Localização:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'lei_localizacao',
                                    ),
                                  ), 
                                  array (
                                    'size' => 50,
                                    'control_name' => 'lei_localizacao',
                                    'id' => 'lei_localizacao'
                                  )) ?>
    </li>
    <?php echo "<li><label></label>" . form_error('ano_localizacao') . "</li>" ?>
    <li>
      <label for="ano_localizacao">Ano da Lei de Localização:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'ano_localizacao',
                                    ),
                                  ), 
                                  array (
                                    'size' => 7,
                                    'control_name' => 'ano_localizacao',
                                    'id' => 'ano_localizacao'
                                  )) ?>
    </li>
    <li>
      <label for="lei_redacao">Lei da Redação Atual:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'lei_redacao',
                                    ),
                                  ), 
                                  array (
                                    'size' => 50,
                                    'control_name' => 'lei_redacao',
                                    'id' => 'lei_redacao'
                                  )) ?>      
    </li>
    <?php echo "<li><label></label>" . form_error('ano_redacao') . "</li>" ?>
    <li>
      <label for="ano_redacao">Ano da Lei da Redação Atual:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'ano_redacao',
                                    ),
                                  ), 
                                  array (
                                    'size' => 7,
                                    'control_name' => 'ano_redacao',
                                    'id' => 'ano_redacao',
                                  )) ?>
    </li>
    <li>
      <label for="lei_criacao">Lei de Criação:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'lei_criacao',
                                    ),
                                  ),
                                  array (
                                    'size' => 50,
                                    'control_name' => 'lei_criacao',
                                    'id' => 'lei_criacao',
                                  )) ?>
    </li>
    <?php echo "<li><label></label>" . form_error('ano_criacao') . "</li>" ?>
    <li>
      <label for="ano_criacao">Ano da Lei de Criação:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'ano_criacao',
                                    ),
                                  ),
                                  array (
                                    'size' => 7,
                                    'control_name' => 'ano_criacao',
                                    'id' => 'ano_criacao'
                                  )) ?>
    </li>
    <li>
      <label for="titulo">Título:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'titulo',
                                    ),
                                  ),
                                  array (
                                    'size' => 80,
                                    'control_name' => 'titulo',
                                    'id' => 'titulo',
                                  )) ?>
    </li>
    <li>
      <label for="capitulo">Capítulo:</label>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'capitulo',
                                    ),
                                  ),
                                  array (
                                    'size' => 80,
                                    'control_name' => 'capitulo',
                                    'id' => 'capitulo',
                                  )) ?>
    </li>
    <li>
      <label for="pena_minima">Pena Mínima:</label>
      <?php echo form_error('pena_minima') ?>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'pena_minima',
                                    ),
                                  ),
                                  array (
                                    'size' => 7,
                                    'control_name' => 'pena_minima',
                                    'id' => 'pena_minima',
                                    'title' => 'Campo deve ser fornecido em número de dias. Ex: Para indicar 2 meses, fornecer 60 dias.'
                                  )) ?>
    </li>
    <li>
      <label for="pena_maxima">Pena Máxima:</label>
      <?php echo form_error('pena_maxima') ?>
      <?php echo object_input_tag($tipo, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'pena_maxima',
                                    ),
                                  ),
                                  array (
                                    'size' => 7,
                                    'control_name' => 'pena_maxima',
                                    'id' => 'pena_maxima',
                                    'title' => 'Campo deve ser fornecido em número de dias. Ex: Para indicar 2 meses, fornecer 60 dias.'
                                  )) ?>
    </li>
    <li>
      <label for="texto_legal">Texto Legal:</label>
      <?php echo object_textarea_tag( $tipo,
                                      array (
                                        0 => 'get',
                                        1 => 
                                        array (
                                          0 => 'texto_legal',
                                        ),
                                      ),
                                      array (
                                        'size' => '30x3',
                                        'control_name' => 'texto_legal',
                                        'id' => 'texto_legal',
                                      )) ?>
    </li>
    <li>
      <label for="obs_aplicacao">Obs. de Aplicação:</label>
      <?php echo object_textarea_tag( $tipo, 
                                      array (
                                        0 => 'get',
                                        1 => 
                                        array (
                                          0 => 'obs_aplicacao',
                                        ),
                                      ),
                                      array (
                                        'size' => '30x3',
                                        'control_name' => 'obs_aplicacao',
                                        'id' => 'obs_aplicacao',
                                      )) ?>
    </li>
    <li>
      <label for="notas_metodologicas">Notas Metodológicas:</label>
      <?php echo object_textarea_tag( $tipo, 
                                      array (
                                        0 => 'get',
                                        1 => 
                                        array (
                                          0 => 'notas_metodologicas',
                                        ),
                                      ),
                                      array (
                                        'size' => '30x3',
                                        'control_name' => 'notas_metodologicas',
                                        'id' => 'notas_metodologicas',
                                      )) ?>
    </li>
    <li>
      <label for="simulado">Simulado:</label>
      <?php echo object_checkbox_tag( $tipo, 
                                      array (
                                        0 => 'get',
                                        1 => 
                                        array (
                                          0 => 'simulado',
                                        ),
                                      ),
                                      array (
                                        'control_name' => 'simulado',
                                        'id' => 'simulado',
                                      )) ?>
    </li>
    <?php if($sf_user->hasCredential('Administrador')): ?>
      <li>
        <label for="aprovado">Aprovado:</label>
        <?php echo object_checkbox_tag( $tipo, 
                                        array (
                                          0 => 'get',
                                          1 => 
                                          array (
                                            0 => 'aprovado',
                                          ),
                                        ),
                                        array (
                                          'control_name' => 'aprovado',
                                          'id' => 'aprovado',
                                        )) ?>
      </li>
    <?php endif; ?>
    <?php if ($tipo->get('id')): ?>
    <li>
      <label for="aprovadopor">Aprovado/Desaprovado por:</label> 
      <?php echo '<label class="labelLeft" id="aprovadopor" name="aprovadorpor">' . $tipo->get('RAprovadoPor')->get('login') . '</label>'; ?>
    </li>
    <li>
      <label for="datacriacao">Data da Criação:</label> 
      <?php 
        if($tipo->getcreated_at())
        {
          $dateFormat = new sfDateFormat('pt_BR');
          $value = $dateFormat->format($tipo->getcreated_at(), 'dd/MM/yyyy HH:mm:ss'); 
          echo '<label class="labelLeft" id="datacriacao" name="datacriacao">' . $value . '</label>';
        }
      ?>
    </li>
    <li>
      <label for="criadopor">Criado por:</label>
      <?php echo '<label class="labelLeft" id="criadopor" name="criadopor">' . $tipo->get('RCriadoPor')->get('login') . '</label>'; ?>
    </li>
    <li>
      <label for="updated_at">Última Alteração:</label>
      <?php 
        if($tipo->getupdated_at())
        {
          $dateFormat = new sfDateFormat('pt_BR');
          $value = $dateFormat->format($tipo->getupdated_at(), 'dd/MM/yyyy HH:mm:ss'); 
          echo '<label class="labelLeft" id="updated_at" name="updated_at">' . $value . '</label>'; 
        } 
      ?>
    </li>
    <li>
      <label for="alteradopor">Alterado por:</label>
      <?php echo '<label class="labelLeft" id="alteradopor" name="alterapor">' . $tipo->get('RAlteradoPor')->get('login') . '</label>'; ?>
    </li>
    <?php endif; ?>
    <li>
      <label for="TipoCriterios">Critérios:</label>
      <?php $value = object_doctrine_admin_double_list($tipo, 
            array (
              0 => 'get',
              1 => 
                array (
                  0 => 'TipoCriterios',
                ),
            ), 
            array (
              'control_name' => 'TipoCriterios',    
              'unassociated_label' => 'Não Associado',
              'associated_label' => 'Associado',
              'text_method' => 'getNome'              
            )); 
            echo $value ? $value : '&nbsp;' ?>
    </li>
  </ul>
</fieldset>


<hr />
<div class="buttons">
  <?php echo (!$sf_user->hasCredential('Administrador') && $tipo->get('aprovado')  ? "" : submit_tag('Salvar') )?>
  <?php if ($tipo->get('id')): ?>
    &nbsp;<?php echo (!$sf_user->hasCredential('Administrador') && $tipo->get('aprovado')  ? "" : link_to('Deletar', 'tipo/delete?id='.$tipo->get('id'), 'post=true&confirm=Você tem certeza?') ) ?>
  <?php endif; ?>
  &nbsp;<?php echo link_to('Cancelar', 'tipo/list') ?>
</div>
</form>
