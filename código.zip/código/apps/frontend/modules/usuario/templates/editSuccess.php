<?php use_helper('ObjectDoctrineAdmin', 'Object', 'Date', 'Validation') ?>

<?php if ($sf_request->hasErrors()): ?>
  <div id="errors">
    <p>Foi encontrado erro nos campos abaixo.</p>
    <p>Por favor, corrija-o para prosseguir.</p>
  </div>
<?php endif; ?>

<?php echo form_tag('usuario/update', 'multipart=true') ?>

<?php echo object_input_hidden_tag($usuario, 'getid') ?>


<fieldset>
  <legend>Formulário Usuário</legend>  
  <ul>
    <li><label></label><?php echo form_error('login') ?></li>
    <li>
    <label for="login">Login:</label>
      <?php echo object_input_tag($usuario,
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'login',
                                          ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'login',
                                    'id' => 'login'  
                                  )) ?>
    </li>
    <li>
      <label></label><?php echo form_error('senha') ?>
    </li>
    <li>
      <label for="senha">Senha:</label>
      <?php echo input_password_tag('senha', $usuario->get('senha')); ?>
    </li>
    <li>
      <label for="nome">Nome:</label>      
      <?php echo object_input_tag($usuario, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'nome',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'nome',
                                    'id' => 'nome'
                                   )) ?>
    </li>
    <li>
      <label for="instituicao">Instituição:</label>
      <?php echo object_input_tag($usuario, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'instituicao',
                                    ),
                                  ), 
                                  array (
                                    'size' => '50',
                                    'control_name' => 'instituicao',
                                    'id' => 'instituicao'
                                  )) ?>
    </li>
    <li>
      <label for="email">E-mail:</label>
      <?php echo object_input_tag($usuario, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'email',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'email',
                                    'id' => 'email'
                                  )) ?>
    </li>
    <li>
      <label></label>    
      <?php echo form_error('Credential') ?>
    </li>
    <li>      
      <label for="Credential">Permissão:</label>
      <?php echo object_select_tag($usuario, 
                                   array (
                                     0 => 'get',
                                     1 => 
                                     array (
                                       0 => 'credential_id',
                                     ),
                                   ), 
                                   array (
                                     'related_class' => 'Credential',
                                     'text_method'  => 'getNome',
                                     'control_name' => 'Credential',
                                     'include_custom' => 'Selecione uma Permissão',
                                     'id' => 'Credential'
                                   )) ?>
    </li>
  </ul>
</fieldset>  
<div class="buttons">
  <?php echo submit_tag('Salvar') ?>
  <?php if ($usuario->get('id')): ?>
    &nbsp;<?php echo link_to('Deletar', 'usuario/delete?id='.$usuario->get('id'), 'post=true&confirm=Você tem certeza?') ?>
    &nbsp;<?php echo link_to('Cancelar', 'usuario/list') ?>
  <?php else: ?>
    &nbsp;<?php echo link_to('Cancelar', 'usuario/list') ?>
  <?php endif; ?>
</div>

</form>
