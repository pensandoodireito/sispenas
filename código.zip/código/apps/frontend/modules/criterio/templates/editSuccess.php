<?php use_helper('ObjectDoctrineAdmin', 'Object', 'Date', 'Validation') ?>

<?php if($sf_request->hasErrors()): ?>
  <div id="errors">
    <p>Foi encontrado erro nos campos abaixo.</p>
    <p>Por favor, corrija-o para prosseguir.</p>
  </div>
<?php endif; ?>

<?php echo form_tag('criterio/update', 'multipart=true') ?>

<?php echo object_input_hidden_tag($criterio, 'getid') ?>

<fieldset>
  <legend>Formulário Critério</legend>
  <ul>
    <li>
      <label></label>
      <?php echo form_error('criterio') ?>
    </li>
    <li>
      <label for="criterio">Criterio:</label>
      <?php echo object_input_tag($criterio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'nome',
                                    ),
                                  ), 
                                  array (
                                    'size' => 80,
                                    'control_name' => 'criterio',
                                    'id' => 'criterio'
                                  )) ?>
    </li>
    <li>
      <label for="categoria">Categoria:</label>
      <?php echo object_input_tag($criterio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'categoria',
                                    ),
                                  ), 
                                  array (
                                    'size' => 80,
                                    'control_name' => 'categoria',
                                    'id' => 'categoria'
                                  )) ?>
    </li>
    <li>
      <label for="descricao">Descrição:</label>
      <?php echo object_textarea_tag($criterio, 
                                     array (
                                       0 => 'get',
                                       1 => 
                                       array (
                                         0 => 'descricao',
                                       ),
                                     ), 
                                     array (
                                       'size' => '30x3',
                                       'control_name' => 'descricao',
                                       'id' => 'descricao'
                                     )) ?>
    </li>
    <li>
      <label for="obs_aplicacao">Obs. Aplicação:</label>
      <?php echo object_textarea_tag($criterio, 
                                     array (
                                       0 => 'get',
                                       1 => 
                                         array (
                                           0 => 'obs_aplicacao',
                                         ),
                                     ), 
                                     array (
                                       'size' => '30x3',
                                       'control_name' => 'obs_aplicacao',
                                       'id' => 'obs_aplicacao'
                                     )) ?>
    </li>
    <li>
      <label for="notas_metodologicas">Notas Metodológicas</label>
      <?php echo object_textarea_tag($criterio, 
                                     array (
                                       0 => 'get',
                                       1 => 
                                       array (
                                         0 => 'notas_metodologicas',
                                       ),
                                     ), 
                                     array (
                                       'size' => '30x3',
                                       'control_name' => 'notas_metodologicas',
                                       'id' => 'notas_metodologicas'
                                     )) ?>
    </li>
    <?php if($sf_user->hasCredential('Administrador')): ?>
      <li>
        <label for="aprovado">Aprovado:</label>
        <?php echo object_checkbox_tag($criterio, 
                                       array (
                                         0 => 'get',
                                         1 => 
                                         array (
                                           0 => 'aprovado',
                                         ),
                                      ), 
                                      array (
                                        'control_name' => 'aprovado',
                                        'id' => 'aprovado'
                                      )) ?>
      </li>
    <?php endif; ?>
    <?php if ($criterio->get('id')): ?>
    <li>
      <label for="aprovadopor">Aprovado/Desaprovado por:</label>
      <?php echo '<label class="labelLeft" id="aprovadopor" name="aprovadorpor">' . $criterio->get('RAprovadoPor')->get('login') . '</label>'; ?>
    </li>
    <li>
      <label for="created_at">Data da Criação:</label>
      <?php 
        if($criterio->getcreated_at())
        {
          $dateFormat = new sfDateFormat('pt_BR');
          $value = $dateFormat->format($criterio->getcreated_at(), 'dd/MM/yyyy HH:mm:ss'); 
          echo '<label class="labelLeft" id="created_at" name="created_at">' . $value . '</label>';
        } 
      ?>
    </li>
    <li>
      <label for="criadopor">Criado por:</label>
      <?php echo '<label class="labelLeft" id="criadopor" name="criadopor">' . $criterio->get('RCriadoPor')->get('login') . '</label>'; ?>
    </li>
    <li>
      <label for="updated_at">Última Alteração:</label>
      <?php 
        if($criterio->getupdated_at())
        {
          $dateFormat = new sfDateFormat('pt_BR');
          $value = $dateFormat->format($criterio->getupdated_at(), 'dd/MM/yyyy HH:mm:ss'); 
          echo '<label class="labelLeft" id="updated_at" name="updated_at">' . $value . '</label>';
        } 
      ?>
    </li>
    <li>
      <label for="alteradopor">Alterado por:</label>
      <?php echo '<label class="labelLeft" id="alteradopor" name="alteradopor">' . $criterio->get('RAlteradoPor')->get('login') . '</label>'; ?>
    </li> 
    <?php endif; ?> 
  </ul>
</fieldset>

<hr />
<div class="buttons">
  <?php echo (!$sf_user->hasCredential('Administrador') && $criterio->get('aprovado')  ? "" : submit_tag('Salvar') )?>
  <?php if ($criterio->get('id')): ?>
    &nbsp;<?php echo (!$sf_user->hasCredential('Administrador') && $criterio->get('aprovado')  ? "" : link_to('Deletar', 'criterio/delete?id='.$criterio->get('id'), 'post=true&confirm=Você tem certeza?') ) ?>
  <?php endif; ?>
  &nbsp;<?php echo link_to('Cancelar', 'criterio/list') ?>
</div>
</form>
