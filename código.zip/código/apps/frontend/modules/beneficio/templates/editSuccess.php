<?php $operadores_numericos = array('=' => '=', '>' => '&gt;', '<' => '&lt;', '>=' => '&gt;=', '<=' => '&lt;=', '<>' => '&lt;&gt;') ?>

<?php $operadores_criterio = array('IN' => 'CONTÉM', 'NOTIN' => 'NÃO CONTÉM') ?>

<?php $operadores_logicos = array('AND' => 'E', 'OR' => 'OU') ?>

<?php use_helper('ObjectDoctrineAdmin', 'Object', 'Date', 'Validation', 'I18N') ?>


<?php if ($sf_request->hasErrors()): ?>  
  <div id="errors">
    <p>Foi encontrado erro nos campos abaixo.</p>
    <p>Por favor, corrija-o(s) para prosseguir.</p>    
  </div>
<?php endif; ?>

<?php echo form_tag('beneficio/update', 'multipart=true') ?>

<?php echo object_input_hidden_tag($beneficio, 'getid') ?>

<fieldset>
  <legend>Formulário Benefício</legend>
  <ul>
    <li>
      <label for="nome">Nome:</label>
      <?php echo form_error('nome') ?>
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'nome',
                                          ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'nome',
                                    'id' => 'nome'  
                                  )) ?>
    </li>
    <?php echo "<li><label></label>" . form_error('ano_localizacao') . "</li>" ?>
    <li>
    <label for="lei_localizacao">Lei de Localização:</label>
      <?php echo form_error('lei_localizacao') ?>
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'lei_localizacao',
                                          ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'lei_localizacao',
                                    'id' => 'lei_localizacao'  
                                  )) ?>
    </li>
    <li>
      <label for="ano_localizacao">Ano da Lei de Localização:</label>
      <?php echo form_error('ano_localizacao') ?>     
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'ano_localizacao',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'ano_localizacao',
                                    'id' => 'ano_localizacao'
                                   )) ?>
    </li>
    <li>
      <label for="lei_atual">Lei da Redação Atual:</label>
      <?php echo form_error('lei_atual') ?>
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'lei_atual',
                                    ),
                                  ), 
                                  array (
                                    'size' => '50',
                                    'control_name' => 'lei_atual',
                                    'id' => 'lei_atual'
                                  )) ?>
    </li>
    <?php echo "<li><label></label>" . form_error('ano_atual') . "</li>" ?>
    <li>
      <label for="ano_atual">Ano da Lei da Redação Atual:</label>
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'ano_atual',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'ano_atual',
                                    'id' => 'ano_atual'
                                  )) ?>
    </li>
    <li>
      <label for="lei_criacao">Lei de Criação:</label>
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'lei_criacao',
                                    ),
                                  ),
                                  array (
                                    'size' => 50,
                                    'control_name' => 'lei_criacao',
                                    'id' => 'lei_criacao',
                                  )) ?>
    </li>
    <?php echo "<li><label></label>" . form_error('ano_criacao') . "</li>" ?>
    <li>
    <label for="ano_criacao">Ano da Lei de Criação:</label>
      <?php echo object_input_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'ano_criacao',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30',
                                    'control_name' => 'ano_criacao',
                                    'id' => 'ano_criacao'
                                  )) ?>
    </li>
    <li>
    <label for="texto_legal">Texto Legal:</label>
      <?php echo form_error('texto_legal') ?>
      <?php echo object_textarea_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'texto_legal',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30x3',
                                    'control_name' => 'texto_legal',
                                    'id' => 'texto_legal'
                                  )) ?>
    </li>
    <li>
    <label for="descricao_completa">Descrição Completa:</label>
      <?php echo form_error('descricao_completa') ?>
      <?php echo object_textarea_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'descricao_completa',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30x3',
                                    'control_name' => 'descricao_completa',
                                    'id' => 'descricao_completa'
                                  )) ?>
    </li>
    <li>
    <label for="criterio_nao_generalizavel">Critério Não Generalizável:</label>
      <?php echo form_error('criterio_nao_generalizavel') ?>
      <?php echo object_textarea_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'criterio_nao_generalizavel',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30x3',
                                    'control_name' => 'criterio_nao_generalizavel',
                                    'id' => 'criterio_nao_generalizavel'
                                  )) ?>
    </li>
    <li>
    <label for="notas_metodologicas">Notas Metodológicas:</label>
      <?php echo form_error('notas_metodologicas') ?>
      <?php echo object_textarea_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'notas_metodologicas',
                                    ),
                                  ), 
                                  array (
                                    'size' => '30x3',
                                    'control_name' => 'notas_metodologicas',
                                    'id' => 'notas_metodologicas'
                                  )) ?>
    </li>
    <li>
    <label for="simulado">Simulado:</label>
      <?php echo form_error('simulado') ?>
      <?php echo object_checkbox_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'simulado',
                                    ),
                                  ), 
                                  array (
                                    'control_name' => 'simulado'
                                  )) ?>
    </li>
    <li>
    <label for="aprovado">Aprovado:</label>
      <?php echo form_error('aprovado') ?>
      <?php echo object_checkbox_tag($beneficio, 
                                  array (
                                    0 => 'get',
                                    1 => 
                                    array (
                                      0 => 'aprovado',
                                    ),
                                  ), 
                                  array (
                                    'control_name' => 'aprovado'
                                  )) ?>
    </li>
    <?php if ($beneficio->get('id')): ?>
    <li>
      <label for="aprovadopor">Aprovado por:</label>
      <?php echo '<label class="labelLeft" id="aprovadopor" name="aprovadorpor">' . $beneficio->get('RAprovadoPor')->get('login') . '</label>'; ?>
    </li>
    <li>
      <label for="datacriacao">Data da Criação:</label>
      <td><?php if($beneficio->get('created_at'))
    		{
      			$dateFormat = new sfDateFormat('pt_BR');
      			$value = $dateFormat->format($beneficio->getcreated_at(), 'dd/MM/yyyy HH:mm:ss'); 
      			echo '<label class="labelLeft" id="datacriacao" name="datacriacao">' . $value . '</label>';
       		} ?> 
    	</td>
    </li>
    <li>
      <label for="criadopor">Criado por:</label>
      <?php echo '<label class="labelLeft" id="criadopor" name="criadopor">' . $beneficio->get('RCriadoPor')->get('login') . '</label>'; ?>
    </li>
    <li>
      <label for="dataalteracao">Data Alteração:</label>
      <td><?php if($beneficio->get('updated_at'))
    		{
         		$dateFormat = new sfDateFormat('pt_BR');
      			$value = $dateFormat->format($beneficio->getupdated_at(), 'dd/MM/yyyy HH:mm:ss'); 
      			echo '<label class="labelLeft" id="dataalteracao" name="dataalteracao">' . $value . '</label>';
    		} ?> 
    	</td>
    </li>
    <li>
      <label for="alteradopor">Alterado por:</label>
      <?php echo '<label class="labelLeft" id="alteradopor" name="alteradopor">' . $beneficio->get('RAlteradoPor')->get('login') . '</label>'; ?>
    </li>
    <?php endif; ?>
  </ul>
</fieldset>
<div id="rule">
  <p>Regra de Aplicação</p>
  <fieldset>
    <legend>Parenteses</legend>
      <?php echo button_to_function('(', 'add_open()') ?>
      <?php echo button_to_function(')', 'add_close()') ?>      
  </fieldset>
  <fieldset>
    <legend>Penas Mínima</legend>
    Pena Mínima <?php echo select_tag('pena_minima_op', $operadores_numericos) ?>
    <?php echo input_tag('pena_minima', null, array('title' => 'Campo deve ser fornecido em número de dias. Ex: Para indicar 2 meses, fornecer 60 dias.')) ?>
    <?php echo button_to_function('Adicionar', 'add_pena_min()') ?>
  </fieldset>
  <fieldset>
    <legend>Pena Máxima</legend>
    Pena Máxima <?php echo select_tag('pena_maxima_op', $operadores_numericos) ?>
    <?php echo input_tag('pena_maxima', null, array('title' => 'Campo deve ser fornecido em número de dias. Ex: Para indicar 2 meses, fornecer 60 dias.')) ?>
    <?php echo button_to_function('Adicionar', 'add_pena_max()') ?>
  </fieldset>
  <fieldset>
    <legend>Operador Lógico</legend>
    <?php echo select_tag('logico_op', $operadores_logicos) ?>
    <?php echo button_to_function('Adicionar', 'add_logico()') ?>
  </fieldset>
  <fieldset>
    <legend>Critério</legend>
    <?php echo select_tag('operador_criterio', $operadores_criterio) ?>
    <?php echo select_tag('criterio_id',
                             objects_for_select(                               
                               $criterios, 
                               'getId', 
                               'getNome',
                               'null'                                                              
                             ))?>
    <?php echo button_to_function('Adicionar', 'add_criterio()') ?>
  </fieldset>
  <br />
  <br />
  <fieldset>
    <legend>Expressão</legend>
      <ul>
        <li><?php echo input_tag('expressao', $beneficio->get('expressao'), array('size' => 80)) ?></li>
        <?php echo form_error('regra') ?>
        <?php echo form_error('consulta') ?>     
        <?php echo input_tag('regra', $beneficio->get('regra'), array('size' => 120, 'readonly' => 'readonly')) ?>
      </ul>
  </fieldset>
  <br />
  <fieldset>
    <?php echo button_to_function('Limpar', 'limpar()') ?>
  </fieldset>
</div>
<div class="buttons">
  <?php echo (!$sf_user->hasCredential('Administrador') && $beneficio->get('aprovado')  ? "" : submit_tag('Salvar') )?>
  <?php if ($beneficio->get('id')): ?>
    &nbsp;<?php echo (!$sf_user->hasCredential('Administrador') && $beneficio->get('aprovado')  ? "" : link_to('Apagar', 'beneficio/delete?id='.$beneficio->get('id'), 'post=true&confirm=Você tem certeza?') )?>
    &nbsp;<?php echo link_to('Cancelar', 'beneficio/list') ?>
  <?php else: ?>
    &nbsp;<?php echo link_to('Cancelar', 'beneficio/list') ?>
  <?php endif; ?>
</div>
</form>