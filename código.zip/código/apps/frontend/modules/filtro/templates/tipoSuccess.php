<h1>Tipos</h1>

<table>
<thead>

<tr>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'artigo'): ?>
    <?php echo link_to(('Artigo'), 'filtro/filter?sort=artigo&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Artigo'), 'filtro/filter?sort=artigo&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'nome'): ?>
    <?php echo link_to(('Nome'), 'filtro/filter?sort=nome&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Nome'), 'filtro/filter?sort=nome&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'lei_localizacao'): ?>
    <?php echo link_to(('Lei Localização'), 'filtro/filter?sort=lei_localizacao&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Lei Localização'), 'filtro/filter?sort=lei_localizacao&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'ano_localizacao'): ?>
    <?php echo link_to(('Ano Localização'), 'filtro/filter?sort=ano_localizacao&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Ano Localização'), 'filtro/filter?sort=ano_localizacao&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'pena_minima'): ?>
    <?php echo link_to(('Pena Mínima'), 'filtro/filter?sort=pena_minima&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Pena Mínima'), 'filtro/filter?sort=pena_minima&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'pena_maxima'): ?>
    <?php echo link_to(('Pena Máxima'), 'filtro/filter?sort=pena_maxima&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Pena Máxima'), 'filtro/filter?sort=pena_maxima&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'texto_legal'): ?>
    <?php echo link_to(('Texto Legal'), 'filtro/filter?sort=texto_legal&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Texto Legal'), 'filtro/filter?sort=texto_legal&type=asc') ?>
    <?php endif; ?>
  </th>
  <th>
    <?php if ($sf_user->getAttribute('sort', null, 'sf_admin/filtro/sort') == 'simulado'): ?>
    <?php echo link_to(('Simulação'), 'filtro/filter?sort=simulado&type='.($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort') == 'asc' ? 'desc' : 'asc')) ?>
    (<?php echo ($sf_user->getAttribute('type', 'asc', 'sf_admin/filtro/sort')) ?>)
    <?php else: ?>
    <?php echo link_to(('Simulação'), 'filtro/filter?sort=simulado&type=asc') ?>
    <?php endif; ?>
  </th>
</tr>
</thead>
<tbody>

<?php foreach ($pager->getResults() as $tipo): ?>
<tr>      
  <td><?php echo $tipo->get('artigo'); ?></td>
  <td><?php echo link_to($tipo->get('nome'), 'tipo/show?id='.$tipo->get('id')); ?></td>
  <td><?php echo $tipo->get('lei_localizacao'); ?></td>
  <td><?php echo $tipo->get('ano_localizacao'); ?></td>
  <td><?php echo Convert::month2year($tipo->get('pena_minima')); ?></td>
  <td><?php echo Convert::month2year($tipo->get('pena_maxima')); ?></td>
  <td><?php echo $tipo->get('texto_legal'); ?></td>
  <td><?php echo ($tipo->get('simulado') ? "Sim" : "Não"); ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<div id="pagination">
  <?php if ($pager->haveToPaginate()): ?>
          <?php echo link_to(image_tag(sfConfig::get('sf_admin_web_dir').'/images/first.png', array('align' => 'absmiddle', 'alt' => 'Primeiro', 'title' => 'Primeiro')), 'filtro/filter?page=1') ?>
          <?php echo link_to(image_tag(sfConfig::get('sf_admin_web_dir').'/images/previous.png', array('align' => 'absmiddle', 'alt' => 'Anterior', 'title' => 'Anterior')), 'filtro/filter?page='.$pager->getPreviousPage()) ?>
        
          <?php foreach ($pager->getLinks() as $page): ?>
            <?php echo link_to_unless($page == $pager->getPage(), $page, 'filtro/filter?page='.$page) ?>
          <?php endforeach; ?>
        
          <?php echo link_to(image_tag(sfConfig::get('sf_admin_web_dir').'/images/next.png', array('align' => 'absmiddle', 'alt' => 'Próximo', 'title' => 'Próximo')), 'filtro/filter?page='.$pager->getNextPage()) ?>
          <?php echo link_to(image_tag(sfConfig::get('sf_admin_web_dir').'/images/last.png', array('align' => 'absmiddle', 'alt' => 'Último', 'title' => 'Último')), 'filtro/filter?page='.$pager->getLastPage()) ?>
        <?php endif; ?>
        
  <?php echo $pager->getNbResults() ?> encontrado(s).
      Mostrando de <?php echo $pager->getFirstIndice() ?> a <?php echo $pager->getLastIndice() ?>.      
</div>
<div id="buttons">
  <?php echo form_tag('filtro/index', 'multipart=true') ?>
    <?php echo submit_tag('Voltar') ?>
  </form>
</div>