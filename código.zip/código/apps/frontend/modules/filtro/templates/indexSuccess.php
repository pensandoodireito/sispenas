<?php use_helper('Object', 'Validation') ?>

<?php if ($sf_request->hasErrors()): ?>  
  <div id="errors" style="padding:10px;">
    Por favor, corrija os erros abaixo:
    <?php if  ($sf_request->hasError('erro_consulta')): ?>
      <ul>    
        <li>
          <?php echo $sf_request->getError('erro_consulta') ?>
        </li>    
      </ul>    
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php $operadores_numericos = array('=' => '=', '>' => '&gt;', '<' => '&lt;', '>=' => '&gt;=', '<=' => '&lt;=', '<>' => '&lt;&gt;') ?>

<?php $operadores_texto = array('=' => '=', '<>' => '&lt;&gt;') ?>

<?php $operadores_simulado = array('TODOS', 'SIM', 'NÃO') ?>

<h1>Filtro</h1>

<?php echo form_tag('filtro/filter', array('method' => 'get', 'multipart' => true)) ?>

<fieldset>
  <legend>Formulário Filtro</legend>
  <ul>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('beneficio_tipo') ?>
      </div>
    </li>
    <li>
      <label for="beneficio">Benefício:</label>
      <?php echo select_tag('filters[beneficio_id]',
                             objects_for_select(                               
                               $beneficios, 
                               'getId', 
                               'getNome',
                               'null',
                               array('include_custom' => 'NENHUM')                               
                             ),
                             array('onchange' => 'selecao()', 'style' => 'width:500px'))?>     
    </li>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('beneficio_tipo') ?>
      </div>
    </li>
    <li>
    <label for="beneficio">Tipo:</label>
      <?php echo select_tag('filters[tipo_id]',
                             objects_for_select(                               
                               $tipos, 
                               'getId', 
                               'getNome',
                               'null',
                               array('include_custom' => 'NENHUM')                               
                             ),
                             array('onchange' => 'selecao()', 'style' => 'width:500px'))?>
    </li>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('filters{pena_minima}') ?>
      </div>
    </li>
    <li>
      <label for="pena_minima_op">Pena Mínima:</label>
      <?php echo select_tag('filters[pena_minima_op]', $operadores_numericos) ?>
      <?php echo input_tag('filters[pena_minima]', null, array('title' => 'Campo deve ser fornecido em número de dias. Ex: Para indicar 2 meses, fornecer 60 dias.')) ?>
    </li>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('filters{pena_maxima}') ?>
      </div>
    </li>    
    <li>
      <label for="pena_maxima_op">Pena Máxima:</label>
      <?php echo select_tag('filters[pena_maxima_op]', $operadores_numericos) ?>
      <?php echo input_tag('filters[pena_maxima]', null, array('title' => 'Campo deve ser fornecido em número de dias. Ex: Para indicar 2 meses, fornecer 60 dias.')) ?>
    </li>      
    <li>
      <label for="lei_localizacao_op">Lei de Localização:</label>
      <?php echo select_tag('filters[lei_localizacao_op]', $operadores_texto) ?>
      <?php echo input_tag('filters[lei_localizacao]') ?>
    </li>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('filters{ano_localizacao}') ?>
      </div>    
    <li>      
        <label for="ano_localizacao_op">Ano da Lei de Localização:</label>
        <?php echo select_tag('filters[ano_localizacao_op]', $operadores_numericos) ?>
        <?php echo input_tag('filters[ano_localizacao]') ?>
    </li>
    <li>
      <label for="lei_redacao_op">Lei da Redação Atual:</label>
      <?php echo select_tag('filters[lei_redacao_op]', $operadores_texto) ?>
      <?php echo input_tag('filters[lei_redacao]') ?>
    </li>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('filters{ano_redacao}') ?>
      </div>
    </li>        
    <li>
      <label for="ano_redacao_op">Ano da Lei da Redação Atual:</label>
      <?php echo select_tag('filters[ano_redacao_op]', options_for_select($operadores_numericos)) ?>
      <?php echo input_tag('filters[ano_redacao]') ?>      
    </li>
    <li>
      <label for="lei_criacao_op">Lei de Criação:</label>
      <?php echo select_tag('filters[lei_criacao_op]', $operadores_texto) ?>
      <?php echo input_tag('filters[lei_criacao]') ?>
    </li>
    <li>
      <div style="margin-left: 195px;">
        <?php echo form_error('filters{ano_criacao}') ?>
      </div>
    </li>      
    <li>
      <label for="ano_criacao_op">Ano da Lei de Criação:</label>
      <?php echo select_tag('filters[ano_criacao_op]', $operadores_numericos) ?>      
      <?php echo input_tag('filters[ano_criacao]') ?>      
    </li>    
    <li>
      <label for="titulo">Título:</label>
      <?php echo select_tag('filters[titulo_op]', $operadores_texto) ?>
      <?php echo input_tag('filters[titulo]') ?>
    </li>
    <li>
      <label for="capitulo">Capítulo:</label>
      <?php echo select_tag('filters[capitulo_op]', $operadores_texto) ?>
      <?php echo input_tag('filters[capitulo]') ?>
    </li>
    <li>
      <label for="simulado">Simulado:</label>
      <?php echo select_tag('filters[simulado_op]', $operadores_simulado) ?>
    </li>
  </ul>
</fieldset>

<div class="buttons">
  <?php echo submit_tag(('Filtrar'), 'name=filter class=sf_admin_action_filter') ?>
</div>
</form>