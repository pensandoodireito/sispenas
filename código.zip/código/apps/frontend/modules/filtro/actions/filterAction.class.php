<?php
class filterAction extends sfAction
{
  public function execute()
  { 
    $this->processFilters();
    $this->processSort();
    $this->filters = $this->getUser()->getAttributeHolder()->getAll('sf_admin/filtro/filters');
    
    $beneficio_id = (!empty($this->filters['beneficio_id']) ? $this->filters['beneficio_id'] : "" );
    $tipo_id      = (!empty($this->filters['tipo_id']) ? $this->filters['tipo_id'] : "" );
    
    if(empty($beneficio_id) and !empty($tipo_id)){
      $this->getBeneficiosByTipo();
      return $this->setTemplate('beneficio');
    }
    elseif(!empty($beneficio_id) and empty($tipo_id)){
      $this->getTiposByBeneficio();
      return $this->setTemplate('tipo');
    }
    else{
      $this->getTipos();
      return $this->setTemplate('tipo');
    }
  }
  
  protected function getBeneficiosByTipo(){
    $q = new Doctrine_Query();
    
    $tipo_id = $this->filters['tipo_id'];
    
    $q->select('t.id')->from('Tipo t')->where('t.id = ?', array($tipo_id));    
    
    $this->filters = $this->getUser()->getAttributeHolder()->getAll('sf_admin/filtro/filters');
    
    $tipo = $q->execute()->getFirst();

    try{
      $tipos_id = $tipo->getBeneficiosById();
    }
    catch(PDOException $e){
      $this->getRequest()->setError('erro_consulta', 'Há um erro no filtro associado ao benefício. Favor corrigir.');
      $this->forward('filtro', 'index');
    }

    if(!$tipos_id){
      $tipos_id = array(-100);
    }
    
    $this->pager = new sfDoctrinePager('Beneficio', sfConfig::get('app_pager_max_pagination'));    
    $this->pager->getQuery()->from('Beneficio b')->whereIn('b.id', $tipos_id);

    $this->addFiltersCriteria($this->pager->getQuery());
    $this->addSortCriteria($this->pager->getQuery(), 'Beneficio');
    
    $this->pager->setPage($this->getRequestParameter('page', $this->getUser()->getAttribute('page', 1)));

    if ($this->getRequestParameter('page')) {
        $this->getUser()->setAttribute('page', $this->getRequestParameter('page'));
    }
    
    $this->pager->init();
  }
  
  protected function getTiposByBeneficio(){
    $beneficio_id = $this->filters['beneficio_id'];    
    
    $q = new Doctrine_Query();

    $beneficio = $q->select('b.id, b.expressao')->from('Beneficio b')->where('b.id = ?', array($beneficio_id))->execute()->getFirst();

    try{
      $tipos_id = $beneficio->getTiposById();
    }
    catch(PDOException $e){
      $this->getRequest()->setError('erro_consulta', 'Há um erro no filtro associado ao benefício. Favor corrigir.');
      $this->forward('filtro', 'index');
    }

    if(!$tipos_id){
      $tipos_id= array(-100);
    }
    
    $this->pager = new sfDoctrinePager('Tipo', sfConfig::get('app_pager_max_pagination'));    
    $this->pager->getQuery()->from('Tipo t')->whereIn('t.id', $tipos_id);
       
    $this->addFiltersCriteria($this->pager->getQuery());
    $this->addSortCriteria($this->pager->getQuery(), 'Tipo');
    
    $this->pager->setPage($this->getRequestParameter('page', $this->getUser()->getAttribute('page', 1)));

    if ($this->getRequestParameter('page')) {
        $this->getUser()->setAttribute('page', $this->getRequestParameter('page'));
    }
    
    $this->pager->init();    
  }

  protected function getTipos(){
   
    $this->pager = new sfDoctrinePager('Tipo', sfConfig::get('app_pager_max_pagination'));    
    $this->pager->getQuery()->from('Tipo t');
       
    $this->addFiltersCriteria($this->pager->getQuery());
    $this->addSortCriteria($this->pager->getQuery(), 'Tipo');
    
    $this->pager->setPage($this->getRequestParameter('page', $this->getUser()->getAttribute('page', 1)));

    if ($this->getRequestParameter('page')) {
        $this->getUser()->setAttribute('page', $this->getRequestParameter('page'));
    }
    
    $this->pager->init();    
  }
  
  protected function processFilters ()
  {
    if ($this->getRequest()->hasParameter('filter'))
    {
      $filters = $this->getRequestParameter('filters');
      $this->getUser()->getAttributeHolder()->removeNamespace('sf_admin/filtro');
      $this->getUser()->getAttributeHolder()->removeNamespace('sf_admin/filtro/filters');
      $this->getUser()->getAttributeHolder()->add($filters, 'sf_admin/filtro/filters');
    }
  }
  
  protected function addFiltersCriteria($q){
    
    if(!empty($this->filters['pena_minima'])){
      $op = $this->filters['pena_minima_op'];
      $q->addWhere("t.pena_minima $op ?", $this->filters['pena_minima']);
    }
    
    if(!empty($this->filters['pena_maxima'])){      
      $op = $this->filters['pena_maxima_op'];
      $q->addWhere("t.pena_maxima $op ?", $this->filters['pena_maxima']);
    }

    if(!empty($this->filters['lei_localizacao'])){
      $op = $this->filters['lei_localizacao_op'];
      $q->addWhere("t.lei_localizacao $op ?", $this->filters['lei_localizacao']);
    }

    if(!empty($this->filters['ano_localizacao'])){
      $op = $this->filters['ano_localizacao_op'];
      $q->addWhere("t.ano_localizacao $op ?", $this->filters['ano_localizacao']);
    }
    
    if(!empty($this->filters['lei_redacao'])){
      $op = $this->filters['lei_redacao_op'];
      $q->addWhere("t.lei_redacao $op ?", $this->filters['lei_redacao']);
    }
    
    if(!empty($this->filters['ano_redacao'])){
      $op = $this->filters['ano_redacao_op'];
      $q->addWhere("t.ano_redacao $op ?", $this->filters['ano_redacao']);
    }
    
    if(!empty($this->filters['lei_criacao'])){
      $op = $this->filters['lei_criacao_op'];
      $q->addWhere("t.lei_criacao $op ?", $this->filters['lei_criacao']);
    }
    
    if(!empty($this->filters['ano_criacao'])){
      $op = $this->filters['ano_criacao_op'];
      $q->addWhere("t.ano_criacao $op ?", $this->filters['ano_criacao']);
    }
    
    if(!empty($this->filters['titulo'])){
      $op = $this->filters['titulo_op'];
      $q->addWhere("t.titulo $op ?", $this->filters['titulo']);
    }
    
    if(!empty($this->filters['capitulo'])){
      $op = $this->filters['capitulo_op'];
      $q->addWhere("t.capitulo $op ?", $this->filters['capitulo']);
    }
    
    if(!empty($this->filters['simulado_op'])){
      if($this->filters['simulado_op']==1){
        $q->addWhere("t.simulado = ?", 'true');
      }
      elseif($this->filters['simulado_op']==2){
        $q->addWhere("t.simulado = ?", 'false');
      }
    }
  }

  
  protected function processSort ()
  {
    if ($this->getRequestParameter('sort'))
    {
      $this->getUser()->setAttribute('sort', $this->getRequestParameter('sort'), 'sf_admin/filtro/sort');
      $this->getUser()->setAttribute('type', $this->getRequestParameter('type', 'asc'), 'sf_admin/filtro/sort');
    }

    if (!$this->getUser()->getAttribute('sort', null, 'sf_admin/filtro/sort'))
    {
      $this->getUser()->setAttribute('sort', 'nome', 'sf_admin/filtro/sort');
      $this->getUser()->setAttribute('type', $this->getRequestParameter('type', 'asc'), 'sf_admin/filtro/sort');    
    }
  }
  
  protected function addSortCriteria ($q, $tableName)
  {
    if ($sort_column = $this->getUser()->getAttribute('sort', null, 'sf_admin/filtro/sort'))
    {
      $table = sfDoctrine::getTable($tableName);
      $colNames = array_keys($table->getColumns());
      if (!in_array($sort_column, $colNames)) // illegal column name
        return;
      if ($this->getUser()->getAttribute('type', null, 'sf_admin/filtro/sort') == 'asc')
      {
        $q->orderBy(($tableName == 'Beneficio' ? 'b' : 't') . '.' . $sort_column);
      }
      else
      {
        $q->orderBy(($tableName == 'Beneficio' ? 'b' : 't') . '.' . $sort_column.' desc');
      }
    }
  }
  
  public function handleError()
  {
    $this->forward('filtro', 'index');
  }

}
?>