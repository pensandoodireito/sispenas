<?php

/**
 * filtro actions.
 *
 * @package    sf_sandbox
 * @subpackage filtro
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 2692 2006-11-15 21:03:55Z fabien $
 */
class filtroActions extends sfActions
{
  /**
   * Executes index action
   *
   */
  public function executeIndex()
  {
    $this->beneficios = Doctrine_Query::create()->from("Beneficio b")->orderBy("b.nome")->execute();
    
    $this->tipos      = Doctrine_Query::create()->from("Tipo t")->orderBy("t.nome")->execute();
  }
}
