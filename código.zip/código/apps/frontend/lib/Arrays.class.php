<?php

class Arrays {
  
  public static function create($minvalue, $maxvalue){
    $array = array('' => '');

    if(!$minvalue || !$maxvalue){
      for($i = $minvalue; $i <= $maxvalue; $i++){
        $array[$i] = $i;   
      }
    }
    return $array;
  }
}

?>