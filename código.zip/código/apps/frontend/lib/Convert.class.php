<?php

class Convert {

  public static function month2year($dia){
    $result    = "Erro";
    $strYear   = "Erro";
    $strMonth  = "Erro";
    $strDia    = "Erro";
    $contMonth = 0;
    $contYear  = 0;
    $contDia   = 0;

    while($dia >= 30){
      $contMonth++;
      $dia -= 30;
    }

    $month=$contMonth;

    while($month >= 12){
      $contYear++;
      $month -= 12;
    }

    if($contYear == 0){
      $strYear = "";
    }
    else if($contYear == 1){
      $strYear = "$contYear ano";
    }
    else{
      $strYear = "$contYear anos";
    }

    if($month == 0){
      $strMonth = "";
    }
    else if($month == 1){
      $strMonth = "$month mês";
    }
    else{
      $strMonth = "$month meses";
    }

    if($dia == 0){
      $strDia = "";
    }
    else if($dia == 1){
      $strDia = "$dia dia";
    }
    else{
      $strDia = "$dia dias";
    }

    $result = $strYear . ($strYear != '' && $strMonth != ''? ' e ' : '') . $strMonth . ($strDia != '' && $strMonth != ''? ' e ' : '') . $strDia;

if ($result == ''){$result = 0;}

    return $result;
  }
}

?>
