<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>

<?php include_http_metas() ?>
<?php include_metas() ?>

<?php include_title() ?>

<link rel="shortcut icon" href="/favicon.ico" />

</head>
<body>

<div id='wrap'>

  <div id='header'>
    <h1 id="logo_fgv">FGV</h1>
    <h1 id="logo_pnud">PNUD</h1>
    <h2>SISPENAS</h2>
    <h1 id="logo_sal">SAL</h1>
  </div>
  <div id='main'>
    <div id='recuoMenu'>
    </div>
    <?php if ($sf_user->isAuthenticated()):?>
      <div id='menu'>
        <ul>
          <?php if($sf_user->hasCredential('Administrador')): ?>
            <li><?php echo link_to('Usuários', 'usuario/list') ?></li>
          <?php endif; ?>          
          <?php if($sf_user->hasCredential('Administrador') or $sf_user->hasCredential('Alimentador')): ?>
            <li><?php echo link_to('Critérios', 'criterio/list') ?></li>
          <?php endif; ?>
            <li><?php echo link_to('Tipos', 'tipo/list') ?></li>
            <li><?php echo link_to('Benefícios', 'beneficio/list') ?></li>
          <li><?php echo link_to('Filtro', 'filtro/index') ?></li>
          <?php if(!$sf_user->hasCredential('Usuario')): ?>
			  <li><?php echo link_to('Sair', 'security/logout') ?></li>
          <?php endif; ?>
        </ul>  
      </div>
      <?php endif; ?>
      <div id='content'>
        <?php echo $sf_data->getRaw('sf_content') ?>
      </div>
  </div>
  <div id='footer'>
  </div>

</div>

</body>
</html>
